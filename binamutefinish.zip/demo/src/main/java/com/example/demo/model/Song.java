package com.example.demo.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "songs")
public class Song {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private long id;

		@Column(name = "genre")
		private String genre;

		@Column(name = "title")
		private String title;

		@Column(name = "author")
		private String author;

		@ManyToMany(mappedBy = "songs", fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
		private Set<User> users = new HashSet<>();

		public Set<User> getUsers() {
			return users;
		}

		public void setUsers(Set<User> users) {
			this.users = users;
		}
		
		@ManyToMany(mappedBy = "songs", fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
		private Set<Playlist> playlists = new HashSet<>();
		
		public Set<Playlist> getPlaylists() {
			return playlists;
		}

		public void setPlaylists(Set<Playlist> playlists) {
			this.playlists = playlists;
		}

		public Song() {}

		public Song(String title, String author, String genre) {

			this.title = title;
			this.author = author;
			this.genre = genre;
		}

		@Override
		public String toString() {
			return "Entity [id=" + id + ", genre=" + genre + ", title=" + title + ", author=" + author + "]";
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getGenre() {
			return genre;
		}

		public void setGenre(String genre) {
			this.genre = genre;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getAuthor() {
			return author;
		}

		public void setAuthor(String author) {
			this.author = author;
		}
}
