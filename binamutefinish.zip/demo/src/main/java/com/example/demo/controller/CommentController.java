package com.example.demo.controller;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Comment;
import com.example.demo.model.CommentRepository;
import com.example.demo.model.Song;
import com.example.demo.model.User;
import com.example.demo.model.UserRepository;
import com.example.demo.request.AddSongRequest;
import com.example.demo.response.MessageResponse;

@CrossOrigin(origins = "http://localhost:8081") 
@RestController
@RequestMapping("/api")
public class CommentController {

	@Autowired
	UserRepository userRepository;
	@Autowired
	CommentRepository commentRepository;
	
	@GetMapping("/{uid}/comments")  // e.g., http://localhost:8080/api/2/course for student with id=2
	public ResponseEntity<?> findCommentByAddingToUser(@PathVariable("sid") Long sid, @RequestParam(required = false) Boolean adding) {
		try {
			Optional<User> userData = userRepository.findById(sid);
			if (userData.isPresent()) {
				User user = userData.get();
				Set<Comment> addingComments = user.getComments();
				if(adding) {
					return new ResponseEntity<>(addingComments, HttpStatus.OK);
				}
				Set<Comment> unaddingComment = new HashSet<Comment>(commentRepository.findAll());
				unaddingComment.removeAll(addingComments);
				if (unaddingComment.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(unaddingComment, HttpStatus.OK);
			} else {
				MessageResponse msg = new MessageResponse("No Such a Student");
				return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("/{uid}/comments")
	public ResponseEntity<?> addCommentToUser(@PathVariable("id") Long uid , @Valid @RequestBody AddSongRequest addSongRequest) {
		try {
			String action = addSongRequest.getAction();
			Long code = addSongRequest.getId();
			Optional<User> userData = userRepository.findById(uid);
			if (userData.isPresent()) {
				User user = userData.get();
				Optional<Comment> commentData = commentRepository.findById(code);
				if (commentData.isPresent()) {
					Comment comment = commentData.get();
					if(action.equals("add")) {
						user.addComment(comment);
					}
					user = userRepository.save(user);
					return new ResponseEntity<>(user, HttpStatus.OK);
				} else {
					MessageResponse msg = new MessageResponse("No Such a Course");
					return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
				}
			} else {
				MessageResponse msg = new MessageResponse("No Such a Course");
				return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
