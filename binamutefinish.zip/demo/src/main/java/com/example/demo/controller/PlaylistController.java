package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Playlist;
import com.example.demo.model.PlaylistRepository;
import com.example.demo.model.User;
import com.example.demo.model.UserRepository;
import com.example.demo.request.PlaylistRequest;
import com.example.demo.response.MessageResponse;


@CrossOrigin(origins="http://localhost:8081")
@RestController
@RequestMapping("/api")
public class PlaylistController {

	@Autowired
	PlaylistRepository playlistRepository;
	
	@Autowired
	UserRepository userRepository;

	@GetMapping("/{uid}/playlists")
	public ResponseEntity<?> findPlaylistByUser(@PathVariable("sid") Long sid, @RequestParam(required = false) Boolean created) {
		try {
			Optional<User> userData = userRepository.findById(sid);
			if (userData.isPresent()) {
				User user = userData.get();
				Set<Playlist> createdPlaylist = user.getPlaylists();
				if(created) {
					return new ResponseEntity<>(createdPlaylist, HttpStatus.OK);
				}
				else {
				MessageResponse msg = new MessageResponse("No Such a Playlist");
				return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
				}
			} 
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return null;
	}
	
	@GetMapping("/playlists")
	public ResponseEntity<List<Playlist>> getAllPlaylists(@RequestParam(required = false) String title) {

		try {
			List<Playlist> playlists = new ArrayList<Playlist>();
			if (title == null) {
				playlistRepository.findAll().forEach(playlists::add);
			} else {
				playlistRepository.findByTitle(title).forEach(playlists::add);
			}
			if (playlists.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(playlists, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/{uid}/playlists/{pid}")
	public ResponseEntity<Playlist> getPlaylistById(@PathVariable("pid") long id) {
		Optional<Playlist> PlaylistData = playlistRepository.findById(id);

		if (PlaylistData.isPresent()) {
			return new ResponseEntity<>(PlaylistData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/{uid}/playlists/title")
	public ResponseEntity<List<Playlist>> getPlaylistByTitle(@PathVariable("title") String title) {
		List<Playlist> playlistData = playlistRepository.findByTitle(title);

		if (playlistData.size() > 0) {
			return new ResponseEntity<>(playlistData, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	

	@PostMapping("/{uid}/playlists")
	public ResponseEntity<Playlist> createPlaylist(@RequestBody Playlist playlist) {
		try {
			Playlist _playlist = playlistRepository.save(new Playlist(playlist.getTitle()));
			return new ResponseEntity<>(_playlist, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PutMapping("/{uid}/playlists")
	public ResponseEntity<Playlist> updatePlaylist(@PathVariable("id") long id, @RequestBody Playlist playlist) {
		Optional<Playlist> playlistData = playlistRepository.findById(id);

		if (playlistData.isPresent()) {
			String title = playlistData.get().getTitle();
			if (title.equals(PlaylistRequest.getTitle())) {
				return new ResponseEntity<>(playlistData.get(), HttpStatus.OK);
			}	
		} else 
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		return null;
		
	}
	
	@DeleteMapping("/{uid}/playlists")
	public ResponseEntity<HttpStatus> deletePlaylist(@PathVariable("id") long id) {
		try {
			playlistRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/playlists")
	public ResponseEntity<HttpStatus> deleteAllTutorials() {
		try {
			playlistRepository.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
}
