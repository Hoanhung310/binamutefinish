package com.example.demo.request;

import javax.validation.constraints.NotBlank;

public class PlaylistRequest {

	@NotBlank(message = "Playlist title cannot be blank")
	private static String title;

	public static String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
