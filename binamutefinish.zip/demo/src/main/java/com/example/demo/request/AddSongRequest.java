package com.example.demo.request;

import javax.validation.constraints.NotBlank;

public class AddSongRequest {
	@NotBlank(message = "Playlist title cannot be blank")
	private String playlistTitle;
	
	@NotBlank(message = "UserName cannot be blank")
	private String userName;
	
	@NotBlank(message = "Action cannot be blank")
	private String action;
	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@NotBlank(message = "Song ID cannot be blank")
	private Long id;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPlaylistTitle() {
		return playlistTitle;
	}

	public void setPlaylistTitle(String playlistTitle) {
		this.playlistTitle = playlistTitle;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	
}
