package com.example.demo.controller;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Playlist;
import com.example.demo.model.PlaylistRepository;
import com.example.demo.model.Song;
import com.example.demo.model.SongRepository;
import com.example.demo.model.User;
import com.example.demo.model.UserRepository;
import com.example.demo.request.AddSongRequest;
import com.example.demo.response.MessageResponse;

@CrossOrigin(origins = "http://localhost:8081") 
@RestController
@RequestMapping("/api")
public class AddSongController {

	@Autowired
	PlaylistRepository playlistRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	SongRepository songRepository;
	
	@GetMapping("/{uid}/songs")  // e.g., http://localhost:8080/api/2/course for student with id=2
	public ResponseEntity<?> findSongByAddingToUser(@PathVariable("sid") Long sid, @RequestParam(required = false) Boolean adding) {
		try {
			Optional<User> userData = userRepository.findById(sid);
			if (userData.isPresent()) {
				User user = userData.get();
				Set<Song> addingSongs = user.getSongs();
				if(adding) {
					return new ResponseEntity<>(addingSongs, HttpStatus.OK);
				}
				Set<Song> unaddingCourses = new HashSet<Song>(songRepository.findAll());
				unaddingCourses.removeAll(addingSongs);
				if (unaddingCourses.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(unaddingCourses, HttpStatus.OK);
			} else {
				MessageResponse msg = new MessageResponse("No Such a Student");
				return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/{uid}/songs")
	public ResponseEntity<?> addRemoveSongToUser(@PathVariable("id") Long uid , @Valid @RequestBody AddSongRequest addSongRequest) {
		try {
			String action = addSongRequest.getAction();
			Long code = addSongRequest.getId();
			Optional<User> userData = userRepository.findById(uid);
			if (userData.isPresent()) {
				User user = userData.get();
				Optional<Song> songData = songRepository.findById(code);
				if (songData.isPresent()) {
					Song song = songData.get();
					if(action.equals("add")) {
						user.addSong(song);
					}else if(action.equals("remove")) {
						user.removeSong(song);
					}
					user = userRepository.save(user);
					return new ResponseEntity<>(user, HttpStatus.OK);
				} else {
					MessageResponse msg = new MessageResponse("No Such a Course");
					return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
				}
			} else {
				MessageResponse msg = new MessageResponse("No Such a Course");
				return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("/{pid}/songs")
	public ResponseEntity<?> addRemoveSongToPlaylist(@PathVariable("id") long pid , @Valid @RequestBody AddSongRequest addSongRequest) {
		try {
			String action = addSongRequest.getAction();
			Long code = addSongRequest.getId();
			Optional<Playlist> playlistData = playlistRepository.findById(pid);
			if (playlistData.isPresent()) {
				Playlist playlist = playlistData.get();
				Optional<Song> songData = songRepository.findById(code);
				if (songData.isPresent()) {
					Song song = songData.get();
					if(action.equals("add")) {
						playlist.addSong(song);
					}else if(action.equals("remove")) {
						playlist.removeSong(song);
					}
					playlist = playlistRepository.save(playlist);
					return new ResponseEntity<>(playlist, HttpStatus.OK);
				} else {
					MessageResponse msg = new MessageResponse("No Such a Course");
					return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
				}
			} else {
				MessageResponse msg = new MessageResponse("No Such a Course");
				return new ResponseEntity<>(msg, HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
