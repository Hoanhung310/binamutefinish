package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Song;
import com.example.demo.model.SongRepository;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class SongController {
	
		@Autowired
		SongRepository songRepository;

		@GetMapping("/songs")
		public ResponseEntity<List<Song>> getAllSongs(@RequestParam(required = false) String title) {

			try {
				List<Song> songs = new ArrayList<Song>();
				if (title == null) {
					songRepository.findAll().forEach(songs::add);
				} else {
					songRepository.findByTitle(title).forEach(songs::add);
				}
				if (songs.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(songs, HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		@GetMapping("/songs/{id}")
		public ResponseEntity<Song> getSongById(@PathVariable("id") long id) {
			Optional<Song> SongData = songRepository.findById(id);

			if (SongData.isPresent()) {
				return new ResponseEntity<>(SongData.get(), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		
		@GetMapping("/songs/title")
		public ResponseEntity<List<Song>> getSongByTitle(@PathVariable("title") String title) {
			List<Song> SongData = songRepository.findByTitle(title);

			if (SongData.size() > 0) {
				return new ResponseEntity<>(SongData, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		
		@GetMapping("/songs/author")
		public ResponseEntity<List<Song>> getSongByAuthor(@PathVariable("author") String author) {
			List<Song> SongData = songRepository.findByAuthor(author);

			if (SongData.size() > 0) {
				return new ResponseEntity<>(SongData, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}

		@PostMapping("/songs")
		public ResponseEntity<Song> createSong(@RequestBody Song song) {
			try {
				Song _song = songRepository.save(new Song(song.getTitle(),song.getAuthor(), song.getGenre()));
				return new ResponseEntity<>(_song, HttpStatus.CREATED);
			} catch (Exception e) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		@PutMapping("/music/{id}")
		public ResponseEntity<Song> updateSong(@PathVariable("id") long id, @RequestBody Song song) {
			Optional<Song> songData = songRepository.findById(id);

			if (songData.isPresent()) {
				Song _data = songData.get();
				_data.setAuthor(song.getAuthor());
				_data.setTitle(song.getTitle());
				_data.setGenre(song.getGenre());
				return new ResponseEntity<>(songRepository.save(_data), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		
		@DeleteMapping("/song/{id}")
		public ResponseEntity<HttpStatus> deleteSong(@PathVariable("id") long id) {
			try {
				songRepository.deleteById(id);
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		@DeleteMapping("/songs")
		public ResponseEntity<HttpStatus> deleteAllTutorials() {
			try {
				songRepository.deleteAll();
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}

}
