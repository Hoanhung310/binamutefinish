package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


import com.example.demo.model.Song;
import com.example.demo.model.SongRepository;
import com.example.demo.model.User;
import com.example.demo.model.UserRepository;

@SpringBootApplication
public class MainApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainApplication.class, args);
	}

	@Bean
	ApplicationRunner init(UserRepository userRepository, SongRepository songRepository) {
		return args -> {
			Song[] songs = { new Song("YOU BELONG WITH ME", "Taylor Swift", "Country"),
					new Song("BEST SONG EVER", "One Direction", "Pop"),
					new Song("LOVE IN THE RAIN", "Rihanna", "RnB") };
			for (int i = 0; i < songs.length; i++) {
				songRepository.save(songs[i]);
			}
			User[] users = { new User("Hung Tran", "1234"),
					new User("Harry Dang", "4567") };
//			for (int i = 0; i < songs.length; i++) {
//				songRepository.save(songs[i]);
//			}
			for (int y = 0; y < users.length; y++) {
				userRepository.save(users[y]);
			}
			
			songRepository.findAll().forEach(System.out::println);
			userRepository.findAll().forEach(System.out::println);
			
		};
		/*
		 * for (int i = 0; i < courses.length; i++) { musicRepository.save(courses[i]);
		 * } for (int i = 0; i < students.length; i++) {
		 * studentRepository.save(students[i]); }
		 */
	}
}
